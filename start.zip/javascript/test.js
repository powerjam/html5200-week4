
//creating arrays for the first time... 
var groceries = ["eggs", "milk", "tofu", "surgar", "Butter"];
//"eggs", "milk", "tofu", "surgar", "Butter"
var colors = new Array();
// "red", "yellow", "pink"
 


var items = new Array(100);

var students = [4,1,2,7,8,9,5,3,12,14,99,44,76,32,25];

// students.pop(); // returns last index of the array, AND removes it
// students.push(13); // puts 13 as the last element of the array, returns length
// students.shift();  // returns the first student index of the array, AND removes it
// students.unshift(6); // puts 30 as the first element of the array, returns length

